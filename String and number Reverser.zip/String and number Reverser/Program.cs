﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;

namespace Letter_Reverser
{
    class Program
    {
        static void Main()
        {
            bool isValid = true;
            int n, Reverse = 0,  rem;
            int iNum;

            string str = "", reverse = "";
            int Length = 0;
            Console.Write("Choose an Option : \n (1)Reverse a string \n (2)Reverse a number \n Your Choice :");
            iNum = int.Parse(Console.ReadLine());


            isValid = (iNum >= 1) && (iNum <= 2);
            if (isValid == true)
            {
                if (iNum == 1)
                {
                    Console.Write("Enter a word : ");
                    str = Console.ReadLine();
                    Length = str.Length - 1;
                    while (Length >= 0)
                    {
                        reverse = reverse + str[Length];
                        Length--;

                    }
                    Console.Write("Reverse word is : " + reverse);
                }
                else if (iNum == 2) 
                {
                    Console.Write("Enter a number: ");
                    n = int.Parse(Console.ReadLine());

                    while (n != 0)
                    {
                        rem = n % 10;
                        Reverse = Reverse * 10 + rem;
                        n /= 10;
                    }
                    Console.WriteLine("Reversed letters :" + reverse);

                }
            }
            else
            {
                Console.Write("Invalid Input.\nPlease try again");
                Main();
            }
                Console.Write("\nPress any key to exit...");
                
                Console.ReadKey();
            
        }
    }
}
